

from ._methods import (
    MarkowitzFrontier
)

__all__ = [
    'MarkowitzFrontier'
]